
//Variables for falling ball
let x0 = 200;
let y0 = 0;
let y0_speed=5;

void setup()
{
  size(400,600);
  background(255);
}

void draw()
{
  //Blank out the background
  fill(255,100);
  rect(0,0,width,height);
  
  //Check if the ball is off the screen
  if(y0 > height+15)  //15 is the radius of the ball
  {
    y0 = -15; //Move it back to just above the screen
    x0 = random(width); //Pick a new random horizontal location on the canvas
    y0_speed = random(3,7); //Pick a new random speed between 3 and 7
  }
  
  
  //Move the ball
  y0 += y0_speed; //Increase the balls y value by the variable
                  //y0_speed each time through the loop
  
  
  //Draw the ball
  fill(255,0,0);
  ellipse(x0, y0, 30,30);
}